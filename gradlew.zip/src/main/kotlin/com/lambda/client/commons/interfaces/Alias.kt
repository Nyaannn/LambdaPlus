package com.lambda.client.commons.interfaces

interface Alias : Nameable {
    val alias: Array<out String>
}