package com.lambda.client.commons.interfaces

interface DisplayEnum {
    val displayName: String
}