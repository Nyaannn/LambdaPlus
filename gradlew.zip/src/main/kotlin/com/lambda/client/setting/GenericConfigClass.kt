package com.lambda.client.setting

import com.lambda.client.commons.interfaces.Nameable

interface GenericConfigClass : Nameable